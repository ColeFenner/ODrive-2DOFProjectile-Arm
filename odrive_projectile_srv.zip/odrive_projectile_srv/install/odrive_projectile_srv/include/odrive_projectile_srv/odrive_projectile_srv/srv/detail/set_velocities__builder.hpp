// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from odrive_projectile_srv:srv/SetVelocities.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "odrive_projectile_srv/srv/set_velocities.hpp"


#ifndef ODRIVE_PROJECTILE_SRV__SRV__DETAIL__SET_VELOCITIES__BUILDER_HPP_
#define ODRIVE_PROJECTILE_SRV__SRV__DETAIL__SET_VELOCITIES__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "odrive_projectile_srv/srv/detail/set_velocities__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace odrive_projectile_srv
{

namespace srv
{

namespace builder
{

class Init_SetVelocities_Request_velocity2
{
public:
  explicit Init_SetVelocities_Request_velocity2(::odrive_projectile_srv::srv::SetVelocities_Request & msg)
  : msg_(msg)
  {}
  ::odrive_projectile_srv::srv::SetVelocities_Request velocity2(::odrive_projectile_srv::srv::SetVelocities_Request::_velocity2_type arg)
  {
    msg_.velocity2 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::odrive_projectile_srv::srv::SetVelocities_Request msg_;
};

class Init_SetVelocities_Request_velocity1
{
public:
  Init_SetVelocities_Request_velocity1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetVelocities_Request_velocity2 velocity1(::odrive_projectile_srv::srv::SetVelocities_Request::_velocity1_type arg)
  {
    msg_.velocity1 = std::move(arg);
    return Init_SetVelocities_Request_velocity2(msg_);
  }

private:
  ::odrive_projectile_srv::srv::SetVelocities_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::odrive_projectile_srv::srv::SetVelocities_Request>()
{
  return odrive_projectile_srv::srv::builder::Init_SetVelocities_Request_velocity1();
}

}  // namespace odrive_projectile_srv


namespace odrive_projectile_srv
{

namespace srv
{

namespace builder
{

class Init_SetVelocities_Response_message
{
public:
  explicit Init_SetVelocities_Response_message(::odrive_projectile_srv::srv::SetVelocities_Response & msg)
  : msg_(msg)
  {}
  ::odrive_projectile_srv::srv::SetVelocities_Response message(::odrive_projectile_srv::srv::SetVelocities_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::odrive_projectile_srv::srv::SetVelocities_Response msg_;
};

class Init_SetVelocities_Response_success
{
public:
  Init_SetVelocities_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetVelocities_Response_message success(::odrive_projectile_srv::srv::SetVelocities_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_SetVelocities_Response_message(msg_);
  }

private:
  ::odrive_projectile_srv::srv::SetVelocities_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::odrive_projectile_srv::srv::SetVelocities_Response>()
{
  return odrive_projectile_srv::srv::builder::Init_SetVelocities_Response_success();
}

}  // namespace odrive_projectile_srv


namespace odrive_projectile_srv
{

namespace srv
{

namespace builder
{

class Init_SetVelocities_Event_response
{
public:
  explicit Init_SetVelocities_Event_response(::odrive_projectile_srv::srv::SetVelocities_Event & msg)
  : msg_(msg)
  {}
  ::odrive_projectile_srv::srv::SetVelocities_Event response(::odrive_projectile_srv::srv::SetVelocities_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::odrive_projectile_srv::srv::SetVelocities_Event msg_;
};

class Init_SetVelocities_Event_request
{
public:
  explicit Init_SetVelocities_Event_request(::odrive_projectile_srv::srv::SetVelocities_Event & msg)
  : msg_(msg)
  {}
  Init_SetVelocities_Event_response request(::odrive_projectile_srv::srv::SetVelocities_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_SetVelocities_Event_response(msg_);
  }

private:
  ::odrive_projectile_srv::srv::SetVelocities_Event msg_;
};

class Init_SetVelocities_Event_info
{
public:
  Init_SetVelocities_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetVelocities_Event_request info(::odrive_projectile_srv::srv::SetVelocities_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_SetVelocities_Event_request(msg_);
  }

private:
  ::odrive_projectile_srv::srv::SetVelocities_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::odrive_projectile_srv::srv::SetVelocities_Event>()
{
  return odrive_projectile_srv::srv::builder::Init_SetVelocities_Event_info();
}

}  // namespace odrive_projectile_srv

#endif  // ODRIVE_PROJECTILE_SRV__SRV__DETAIL__SET_VELOCITIES__BUILDER_HPP_
