// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from odrive_projectile_srv:srv/SetVelocities.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "odrive_projectile_srv/srv/set_velocities.h"


#ifndef ODRIVE_PROJECTILE_SRV__SRV__DETAIL__SET_VELOCITIES__STRUCT_H_
#define ODRIVE_PROJECTILE_SRV__SRV__DETAIL__SET_VELOCITIES__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/SetVelocities in the package odrive_projectile_srv.
typedef struct odrive_projectile_srv__srv__SetVelocities_Request
{
  double velocity1;
  double velocity2;
} odrive_projectile_srv__srv__SetVelocities_Request;

// Struct for a sequence of odrive_projectile_srv__srv__SetVelocities_Request.
typedef struct odrive_projectile_srv__srv__SetVelocities_Request__Sequence
{
  odrive_projectile_srv__srv__SetVelocities_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} odrive_projectile_srv__srv__SetVelocities_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SetVelocities in the package odrive_projectile_srv.
typedef struct odrive_projectile_srv__srv__SetVelocities_Response
{
  bool success;
  rosidl_runtime_c__String message;
} odrive_projectile_srv__srv__SetVelocities_Response;

// Struct for a sequence of odrive_projectile_srv__srv__SetVelocities_Response.
typedef struct odrive_projectile_srv__srv__SetVelocities_Response__Sequence
{
  odrive_projectile_srv__srv__SetVelocities_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} odrive_projectile_srv__srv__SetVelocities_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  odrive_projectile_srv__srv__SetVelocities_Event__request__MAX_SIZE = 1
};
// response
enum
{
  odrive_projectile_srv__srv__SetVelocities_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/SetVelocities in the package odrive_projectile_srv.
typedef struct odrive_projectile_srv__srv__SetVelocities_Event
{
  service_msgs__msg__ServiceEventInfo info;
  odrive_projectile_srv__srv__SetVelocities_Request__Sequence request;
  odrive_projectile_srv__srv__SetVelocities_Response__Sequence response;
} odrive_projectile_srv__srv__SetVelocities_Event;

// Struct for a sequence of odrive_projectile_srv__srv__SetVelocities_Event.
typedef struct odrive_projectile_srv__srv__SetVelocities_Event__Sequence
{
  odrive_projectile_srv__srv__SetVelocities_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} odrive_projectile_srv__srv__SetVelocities_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ODRIVE_PROJECTILE_SRV__SRV__DETAIL__SET_VELOCITIES__STRUCT_H_
