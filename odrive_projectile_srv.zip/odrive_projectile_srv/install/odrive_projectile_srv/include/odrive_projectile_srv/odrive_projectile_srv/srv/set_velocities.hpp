// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ODRIVE_PROJECTILE_SRV__SRV__SET_VELOCITIES_HPP_
#define ODRIVE_PROJECTILE_SRV__SRV__SET_VELOCITIES_HPP_

#include "odrive_projectile_srv/srv/detail/set_velocities__struct.hpp"
#include "odrive_projectile_srv/srv/detail/set_velocities__builder.hpp"
#include "odrive_projectile_srv/srv/detail/set_velocities__traits.hpp"
#include "odrive_projectile_srv/srv/detail/set_velocities__type_support.hpp"

#endif  // ODRIVE_PROJECTILE_SRV__SRV__SET_VELOCITIES_HPP_
