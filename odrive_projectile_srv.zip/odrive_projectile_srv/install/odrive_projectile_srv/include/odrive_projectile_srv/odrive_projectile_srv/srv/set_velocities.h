// generated from rosidl_generator_c/resource/idl.h.em
// with input from odrive_projectile_srv:srv/SetVelocities.idl
// generated code does not contain a copyright notice

#ifndef ODRIVE_PROJECTILE_SRV__SRV__SET_VELOCITIES_H_
#define ODRIVE_PROJECTILE_SRV__SRV__SET_VELOCITIES_H_

#include "odrive_projectile_srv/srv/detail/set_velocities__struct.h"
#include "odrive_projectile_srv/srv/detail/set_velocities__functions.h"
#include "odrive_projectile_srv/srv/detail/set_velocities__type_support.h"

#endif  // ODRIVE_PROJECTILE_SRV__SRV__SET_VELOCITIES_H_
